﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADODemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //GetAllName();
            //SQLInjection("hello");
            SQLInjection("hello' or '1' = '1");
            //SQLRetrieve("hello' or '1' = '1");
            //SQLRetrieve("DocAveDatabaseEncryptionKey");


            Console.ReadLine();

        }

        private static void GetAllName()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = GetConnectionString(ConnectionStringPattern.BySqlConnectionStringBuilder);
                conn.Open();
                Console.WriteLine(conn.State.ToString());

                string commandText = "select * from stest";
                SqlCommand command = new SqlCommand(commandText, conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader["sname"]);
                    }
                }
            }
        }
        private static string GetConnectionString(ConnectionStringPattern pattern)
        {
            string connectionString = string.Empty;

            switch (pattern)
            {
                case ConnectionStringPattern.ByString:
                    connectionString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=test;Integrated Security=False;User ID=sa;Password=sa123456";
                    break;
                case ConnectionStringPattern.BySqlConnectionStringBuilder:
                    SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder();
                    sqlBuilder.DataSource = @"localhost\SQLEXPRESS";
                    sqlBuilder.InitialCatalog = "test";
                    sqlBuilder.IntegratedSecurity = false;
                    sqlBuilder.UserID = "sa";
                    sqlBuilder.Password = "sa123456";
                    connectionString = sqlBuilder.ConnectionString;
                    break;
                case ConnectionStringPattern.ByConfiguration:
                    connectionString = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
                    break;

                default:
                    throw new Exception("Pattern Error");
            }

            return connectionString;
        }

        private static void SQLInjection(string name)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = GetConnectionString(ConnectionStringPattern.BySqlConnectionStringBuilder);
                conn.Open();
                Console.WriteLine(conn.State.ToString());

                string commandText = "select * from stest where sname = '" + name + "' ";
                SqlCommand command = new SqlCommand(commandText, conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader["sname"]);
                    }
                }
            }
        }

        private static void SQLRetrieve(string name)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = GetConnectionString(ConnectionStringPattern.BySqlConnectionStringBuilder);
                conn.Open();
                Console.WriteLine(conn.State.ToString());

                string commandText = "select * from stest where sname = @name";
                SqlCommand command = new SqlCommand(commandText, conn);

                SqlParameter parameter = new SqlParameter("@name", name);
                command.Parameters.Add(parameter);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader["name"]);
                    }
                }
                command.CommandText = "select id from stest";
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader["id"]);
                    }
                }
            }
        }

    }

    public enum ConnectionStringPattern
    {
        ByString,
        BySqlConnectionStringBuilder,
        ByConfiguration
    }
}
