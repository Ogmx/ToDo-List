﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFTest1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (EFModel1Container context = new EFModel1Container())
            {
                Student s1 = new Student();
                s1.Id =1;
                s1.Name ="xiao ming ";
                s1.Age = 3;

                context.Students.Add(s1);
                context.SaveChanges();



            }
            Console.WriteLine("Finished");
            Console.ReadLine();

        }
    }
}
