﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkDemo3
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ModelDemo1Container conatiner = new ModelDemo1Container())
            {
                //Student student1 = new Student();
                //student1.Id = 1;
                //student1.Name = "xiao ming";
                //student1.Age = 19;

                //Student student2 = new Student();
                //student2.Id = 1;
                //student2.Name = "xiao qiang";
                //student2.Age = 20;

                //conatiner.Students.Add(student1);
                //conatiner.Students.Add(student2);
                
                //conatiner.SaveChanges();

                var students = from s in conatiner.Students orderby s.Age descending select s;

                foreach (Student stu in students)
                {
                    Console.Write(String.Format("id : {0} ; Name : {1} ; Age : {2}", stu.Id, stu.Name, stu.Age));
                    Console.WriteLine(string.Empty);
                }

                var student = conatiner.Students.First(s => s.Age == 20);

                Console.WriteLine(student.Age);
            }

            Console.WriteLine("finished");
            Console.ReadLine();
        }
    }
}
