﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    //An interface contains only the signatures of methods, properties, events or indexers
    //An interface can't contain constants, fields, operators, instance constructors, destructors, or types. Interface members are automatically public, and they can't include any access modifiers. Members also can't be static.
    interface IBankAccount
    {
        // A method with no 
        void PayIn(decimal amount);
        bool WithDraw(decimal amount);
        decimal Balance
        { get; }

        
    }

    class SaverAccount : IBankAccount
    {
        private decimal balance;
        public decimal Balance
        {
            get
            {
                return balance;
            }
        }

        public void PayIn(decimal amount)
        {
            balance += amount;
        }

        public bool WithDraw(decimal amount)
        {
            if (balance >= amount)
            {
                balance -= amount;
                return true;
            }
            Console.WriteLine("Withdrawal attempt failed.");
            return false;
        }
    }

    interface ITransferBankAccount : IBankAccount
    {
        bool TransferTo(IBankAccount destination, decimal amount);
    }


    class CurrentAccount : ITransferBankAccount
    {
        private decimal balance;
        public decimal Balance
        {
            get
            {
                return balance;
            }
        }

        public void PayIn(decimal amount)
        {
            balance += amount;
        }

        public bool TransferTo(IBankAccount destination, decimal amount)
        {
            bool result;
            if ((result = WithDraw(amount)) == true)
            {
                destination.PayIn(amount);
            }
            return result;
        }

        public bool WithDraw(decimal amount)
        {
            if (balance >= amount)
            {
                balance -= amount;
                return true;
            }
            Console.WriteLine("Withdrawal attempt failed.");
            return false;
        }
    }
}
