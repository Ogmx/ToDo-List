﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambadaDemo
{
    class Program
    {
        delegate string GetContent(string sayHelloTo);
        delegate string Test(string s1, string s2);

        static void Main(string[] args)
        {
            string name = "tom";
            // Anonymous Method
            GetContent context = delegate (string sayHelloTo)
            {
                return "Hello " + sayHelloTo;
            };

            SayHello(context, name);

            // Lambda Expression C# 3.0 开始  Lambda 运算符 => 左侧是参数比如（string param） 但在Lambda 表达式中是不需要添加类型的，应为系统知道
            // 所以直接(param) 如果只有一个参数那么可以删除括号
            SayHello(param =>
            {
                string retValue = string.Empty;
                retValue = "Hello " + param;
                return retValue;
            },
            name);

            SayHello(param => "Hello " + param, name);

            TestMethod((s1, s2) => { return s1 + s2; }, "Hello ", "jerry");
            
            Console.ReadLine();
        }

        private static void SayHello(GetContent content, string name)
        {
            Console.WriteLine(content(name));
        }

        private static void TestMethod (Test test, string s1, string s2)
        {
            Console.WriteLine(test(s1,s2));
        }

        //SayHello(param => "Hello " + param, name);

        //    SayHello(param => 
        //    { 
        //        string retValue = string.Empty;
        //        retValue = "Hello " + param;
        //        return retValue;
        //    },
        //    name);

        private static void FindAllDemo()
        {
            List<int> list = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            ///////
            
            
            List<int> result = list.FindAll(delegate(int param)
                                {
                                    return param > 5;
                                });

            foreach (int i in result)
            {
                Console.WriteLine(i);
            }

             result = list.FindAll( x => x < 5);

             foreach (int i in result)
             {
                 Console.WriteLine(i);
             }
        }
    }
}
