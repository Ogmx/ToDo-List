﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>() { "John", "Kate", "Mike", "Jo" };
            var result = list.MyWhere(delegate (string s)
                        {
                            return s.StartsWith("J");
                        });
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }


            list.Add("JO");


            foreach (var item in result)
            {
                Console.WriteLine(item);
            }

            //var test = list.Where(s => s.StartsWith("K"));
            ////foreach (var a in test)
            ////{
            ////    Console.WriteLine(a);
            ////}

            // var result = from n in list where n.StartsWith("J") orderby n select n;

            //foreach (var item in result)
            //{
            //    Console.WriteLine(item);
            //}


            string str = "A";
            str.Foo();
            Console.ReadLine();
        }
    }

    //扩展方法：扩展方法是静态方法，可以将方法写入到最初没有提供该方法的类中。对于扩展方法来说，第一个参数是要扩展的类型，它放在this 关键字的后面，用来告知编译器作为这个
    //类的一部分

    public static class StringExtension
    {
        public static void Foo(this string s)
        {
            Console.WriteLine("Foo invoked for {0}", s);
        }
    }

    public static class ListExtension
    {
        public static IEnumerable<T> MyWhere<T>(this List<T> source, Func<T, bool> predicate)
        {
            foreach (T item in source)
            {
                if (predicate(item))   //item.startwith("J")

                {
                   yield return item;  //只有当真正对返回值进行迭代的时候，它会直接进行返回
                }
            }
            
        }
    }
}
