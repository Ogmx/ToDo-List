
1.Demo1
IL(intermediate Language):
C:\Program Files (x86)\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.6.1 Tools

https://docs.microsoft.com/en-us/dotnet/api/system.reflection.emit.opcodes.pop?view=netframework-4.8


https://www.cnblogs.com/zw369/p/3609869.html


JIT
https://www.cnblogs.com/lishidefengchen/p/4363916.html