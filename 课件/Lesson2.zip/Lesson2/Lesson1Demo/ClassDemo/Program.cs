﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VirtualDemo;

namespace ClassDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //MyClass1 c1 = new MyClass1();
            //c1.MyMethod();

            MyClass2 c2 = new MyClass2();
            c2.MyMethod(); 
            Console.ReadLine();
        }
    }

    //oo
    //Class 内部包含的内容：数据成员，函数成员
    //数据成员：字段，常量，事件
    //函数成员：方法，属性，构造函数，终结器,运算符(重载)，索引器
    //https://msdn.microsoft.com/en-us/en-su/library/ms173113.aspx

}

namespace FieldsDemo
{
    class Customer
    {
        public const string DayOfSendingBill = "Monday";
        public string Name;
        public string CustomerID;
    }


    class CustomerWithProperty
    {
        public const string DayOfSendingBill = "Monday";
        private string name;
        private string customerID;
        private int age;
        public readonly DateTime CreateDate;
        public string DisplayName { get; set; }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string CustomerID
        {
            get { return customerID; }
        }

        public int Age
        {
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("Age can not less than 0");
                }
                else
                {
                    age = value;
                }
            }
            get { return age; }
        }

        public CustomerWithProperty()
        {
            customerID = Guid.NewGuid().ToString();
            CreateDate = new DateTime();
        }
    }
}


namespace InheritDemo
{
    class MyBaseClass
    { }

    class MyBaseClass2 
    { }

    interface Iinterface1
    { }

    interface Iinterface2
    { }


    class MyDerivedClass : MyBaseClass,Iinterface1,Iinterface2 //,MyBaseClass2
    {
    }
}

namespace VirtualDemo
{
    class MyBaseClass1
    {
        public void MyMethod()
        {
            Console.WriteLine("MyBaseClass1.MyMethod()");
        }
    }

    class MyClass1 : MyBaseClass1
    {
        //If the method in the derived class is preceded with the new keyword, the method is defined as being independent of the method in the base class.
        //public void MyMethod()
        //{
        //    Console.WriteLine("MyClass1.MyMethod()");
        //}


        ////hidden
        public new void MyMethod()
        {
            Console.WriteLine("MyClass1.MyMethod()");
        }
    }

    //https://msdn.microsoft.com/zh-cn/library/6fawty39.aspx


    class MyBaseClass2
    {
        public virtual void MyMethod()
        {
            Console.WriteLine("MyBaseClass2.MyMethod");
        }

    }

    class MyClass2 : MyBaseClass2
    {
        public override void MyMethod()
        {
            base.MyMethod();
            Console.WriteLine("Myclass2.MyMethod");
        }
    }
}

namespace AbstractDemo
{
    abstract class MyBaseAbstractClass1
    {
        public void MyMethod()
        { }

        public abstract void MyAbstractMethod();

    }

    class MyClass : MyBaseAbstractClass1
    {
        public override void MyAbstractMethod()
        {
            throw new NotImplementedException();
        }
    }
}

namespace SealedDemo
{
    sealed class FinalClass
    {
    }

    //class MyClass : FinalClass
    //{ }

    class A
    {
        public virtual void F()
        {
            Console.WriteLine("A.F");
        }
        public virtual void G()
        {
            Console.WriteLine("A.G");
        }
    }
    class B : A
    {

        //Not recommended
        sealed override public void F()
        {
            Console.WriteLine("B.F");
        }
        override public void G()
        {
            Console.WriteLine("B.G");
        }
    }
    class C : B
    {
        override public void G()
        {
            Console.WriteLine("C.G");
        }

       
    }


}