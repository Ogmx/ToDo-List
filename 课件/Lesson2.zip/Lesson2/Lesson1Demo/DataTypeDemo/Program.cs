﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypeDemo
{
    //Class type
    class Person
    {
        public string Name;
        public int age;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Name = "Tom";
            p1.age = 17;

            //value type
            int i = 8;

            //reference type
            Person p2 = new Person();


            //类型推断：
            var name = "Jerry";
            var age = 25;
            var isRabbit = true;

            Type nameType = name.GetType();
            Type ageType = age.GetType();
            Type isRabbitType = isRabbit.GetType();

            Console.WriteLine("name is type : " + nameType.ToString());
            Console.WriteLine("age is type : " + ageType.ToString());
            Console.WriteLine("isRabbit is type : " + isRabbitType.ToString());


            CTSDemo.CTSDemo1.Test();
            Console.ReadLine();
        }
    }
}

namespace CTSDemo
{
    //C# 认可的预定义类型没有内置于C# 语言中，内置在.net framework中，注意类型实际上
    //任然存储为基本类型，性能没有损失，c# 一共内置了15个预定义类型13个是值类型，2个是引用类型string和object
    class CTSDemo1
    {
        public static void Test()
        {
            sbyte sb = 1;
            short sh = 1;
            int i = 1;
            long l = 1L;
            byte b = 1;
            ushort us = 1;
            uint ui = 1;
            ulong ul= 1;

            float f = 33.3f;
            double d = 33.3;

            decimal de = 33.3m;

            bool bo = true;

            char c = 'a';

            Console.WriteLine(sb.GetType());

            Console.WriteLine(1.ToString());
        }

    }
}

namespace ArrayDemo
{
    class ArrayDemo1
    {
        public static void Test()
        {
            int[] a = new int[3];
            int[] b = new int[3] { 1, 2 ,3};
            int[] c = { 1, 2, 3, 4 };
        }

        public static void PrintValue1(int[] array)
        {
            int length = array.Length;
            for (int i = 0; i < length; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine();
        }

        public static void PrintValue2(int[] array)
        {
            foreach (var i in array)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        }

       
    }
}

namespace ConstDemo
{
    class ConstDemo1
    {
        public static void Test()
        {
            const int MAX_VALUE = 1;
        }
    }
}