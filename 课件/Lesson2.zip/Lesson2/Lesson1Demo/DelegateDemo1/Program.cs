﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo1
{
    class Program
    {
        public delegate string SayHello(string name);
        static void Main(string[] args)
        {
            SayHello sayHello = new SayHello(AssemblyString);
            SayHello sayHello1 = AssemblyString;
            PrintHelloMessage("tom", sayHello);
            PrintHelloMessage("tom", AssemblyString);
            PrintHelloMessage("tom", B);
            Console.ReadLine();
        }

        public static void PrintHelloMessage(string name, SayHello sayHello)
        {
            Console.WriteLine(sayHello(name));
        }

        public static string AssemblyString(string name)
        {
            return "Hello " + name;
        }

        public static string B(string name)
        {
            return "Good Morning " + name;
        }
    }
}
