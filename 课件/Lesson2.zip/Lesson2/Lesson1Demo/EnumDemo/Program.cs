﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //EnumDemo1.Demo1.Test();
            EnumDemo2.Demo2.Test();
        }
    }
}


namespace EnumDemo1
{
    enum ThreadStatus
    {
        NEW = 0,
        RUNABLE = 1,
        RUNNING = 2,
        DEAD = 3,
        BLOCKED =4
    }

    class Demo1
    {
        public static void Test()
        {
            ThreadStatus now = ThreadStatus.RUNNING;
            Console.WriteLine(now);
            Console.WriteLine(now.ToString());
            Console.WriteLine((int)now);
            PrintNames();
            Console.WriteLine(Enum.Parse(typeof(ThreadStatus), "NEW"));
            Console.WriteLine(Enum.GetName(typeof(ThreadStatus), 3));
            
            Console.ReadLine();
        }

        public static void PrintNames()
        {
            string[] names = Enum.GetNames(typeof(ThreadStatus));
            foreach (string name in names)
            {
                Console.Write(name + " ");
                
            }
            Console.WriteLine();
        }

        
        //public static void PrintValues()
        //{
        //    var values = Enum.GetValues(typeof(ThreadStatus));
        //    foreach (var value in values)
        //    {
        //        Console.Write(value + " ");
        //    }

        //    Console.WriteLine();
        //}
    }
}

namespace EnumDemo2
{
    [Flags]
    enum Permissions
    {
        READ = 1,
        WRITE = 2,
        DELETE = 4
    }

    class Demo2
    {
        public static void Test()
        {
            Permissions permission = (Permissions)3;
            Console.WriteLine(permission);
            Console.ReadLine();
        }
    }

}