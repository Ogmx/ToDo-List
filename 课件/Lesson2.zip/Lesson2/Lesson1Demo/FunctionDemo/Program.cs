﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodDemo
{
    class A
    {
        public string name;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Test(1);

            TestParamsArgs("tom","jerry","mike");
            int a = 1;
            int b = 2;
            TestValueArgs(a, b);
            Console.WriteLine("a = {0}", a);
            Console.WriteLine("b = {0}", b);

            string a1 = "a";
            string b1 = "b";
            //默认值传递
            TestStringArgs(a1, b1);
            Console.WriteLine("a1 = {0}", a1);
            Console.WriteLine("b1 = {0}", b1);
            

            A a2 = new A() { name = "A" };
            A b2 = new A() { name = "B" };
            TestReferenceArgs(a2, b2);
            Console.WriteLine(a2.name);
            Console.WriteLine(b2.name);

            TestRefArgs(ref a, ref b);
            Console.WriteLine("a = {0}", a);
            Console.WriteLine("b = {0}", b);

            int i = 10;
            int result = TestOutArgs(out i);
            Console.WriteLine("i = {0}", i);
            Console.WriteLine("result = {0}", result);


            Console.ReadLine();
        }

        public static void Test(int arg)
        {
            Console.WriteLine(arg);
        }

        public static void Test(int arg1, int arg2)
        {
            Console.WriteLine();
        }

        public static void TestParamsArgs(params string[] names)
        {
            foreach (string name in names)
            {
                Console.WriteLine(name + " ");
            }
            Console.WriteLine();
        }
        public static void TestValueArgs(int a, int b)
        {
            a = b;
        }

        public static void TestStringArgs(string a, string b)
        {
            a = b;
        }

        public static void TestReferenceArgs(A a, A b)
        {
            //注意因为传递的实际上是对象的地址，但是对对象底层的修改是被保存的
            //a = b;
            a.name = b.name;
        }

        public static void TestRefArgs(ref int a, ref int b)
        {
            a = b;
        }

        public static int TestOutArgs(out int a)
        {
            a = 100;
            return a - 2;
        }
    }


}
