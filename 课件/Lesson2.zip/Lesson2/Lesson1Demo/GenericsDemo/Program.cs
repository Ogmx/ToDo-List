﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();
            list.Add(1); //boxing convert a value type to a referenct type
            int i = (int)list[0]; //unboxing

            
            List<int> list1 = new List<int>();
            list1.Add(1); //no boxing
            //list1.Add(1L);
            int b = list1[0];

            
        }
    }

    public class GenericList<T>
    {
        void Add(T input) { }
    }
    class TestGenericList
    {
        private class ExampleClass { }
        static void Main1()
        {
            // Declare a list of type int.
            GenericList<int> list1 = new GenericList<int>();

            // Declare a list of type string.
            GenericList<string> list2 = new GenericList<string>();

            // Declare a list of type ExampleClass.
            GenericList<ExampleClass> list3 = new GenericList<ExampleClass>();
        }
    }

    interface IFoo
    { }

    class MyClass<T> where T : IFoo
    { }
}
