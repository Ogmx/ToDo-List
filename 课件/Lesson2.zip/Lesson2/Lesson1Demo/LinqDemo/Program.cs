﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication14
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Teacher> teachers = new List<Teacher>();
            List<Student> students = new List<Student>();
            Teacher t1 = new Teacher();
            t1.Id = 1;
            t1.Name = "1";
            t1.age = 18;

            Teacher t2 = new Teacher();
            t2.Id = 2;
            t2.Name = "2";
            t2.age = 19;
            teachers.Add(t1);
            teachers.Add(t2);

            Student s1 = new Student();
            s1.Id = 3;
            s1.Name = "3";
            s1.TId = 1;

            Student s2 = new Student();
            s2.Id = 4;
            s2.Name = "4";
            s2.TId = 1;

            Student s3 = new Student();
            s3.Id = 5;
            s3.Name = "5";
            s3.TId = 2;
            students.Add(s1);
            students.Add(s2);
            students.Add(s3);

            var student = students.Where<Student>(s => s.TId == teachers.Find(t => t.Name == "1").Id);

            foreach (Student s in student)
            {
                Console.WriteLine(s.Name);
            }
            
            var teacherList = from t in teachers orderby t.age select t;

            foreach (Teacher s in teacherList)
            {
                Console.WriteLine(s.Name + " "  + s.age);
            }


            //students.Where<Student>(s => s.TId == 2 );
            Teacher result = teachers.Find(t => t.Id == students.Find(s => s.Id == 3).TId);
            Console.WriteLine(result.Name);

            Console.ReadLine();
        }

        class Teacher { public int Id; public string Name; public int age; }

        class Student  {public int Id; public string Name; public int TId; }
    }
}
