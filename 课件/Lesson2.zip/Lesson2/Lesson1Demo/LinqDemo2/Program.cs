﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>() { "John", "Kate", "Mike", "Jo" };
            //var result = list.MyWhere(delegate(string s)
            //            {
            //                return s.StartsWith("J");
            //            });
            


            //var test = list.Where(s => s.StartsWith("K"));
            ////foreach (var a in test)
            ////{
            ////    Console.WriteLine(a);
            ////}

            var result = from n in list where n.StartsWith("J") orderby n select n;

            //foreach (var item in result)
            //{
            //    Console.WriteLine(item);
            //}


            string str = "A";
            str.Foo();
            Console.ReadLine();
        }
    }

    //扩展方法：可以将方法写入到最初没有提供该方法的类中。

    public static class StringExtension
    {
        public static void Foo(this string s)
        {
            Console.WriteLine("Foo invoked for {0}", s);
        }
    }

    public static class ListExtension
    {
        public static IEnumerable<T> MyWhere<T>(this List<T> source, Func<T, bool> predicate)
        {
            foreach (T item in source)
            {
                if (predicate(item))   //item.startwith("J")

                {
                   yield return item;  //只有当真正对返回值进行迭代的时候，它会直接进行返回
                }
            }
            
        }
    }
}
