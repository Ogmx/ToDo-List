﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NameSpaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            A.SameName s1 = new A.SameName();
            B.SameName s2 = new B.SameName();
            NetFramework.CSharp.My.Test test = null;

        }//
    }

   
}

namespace A
{
    class SameName
    { }
}

namespace B
{
    class SameName
    { }
}

namespace NetFramework
{
    namespace CSharp
    {
        namespace My
        {
            class Test
            { }
        }
    }
}


//namespace NetFramework.CSharp.My
//{
//    class Test { }
//}