﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            string string1 = "This is a string created by assignment.";
            Console.WriteLine(string1);
            string string2a = "The path is C:\\PublicDocuments\\Report1.doc";
            Console.WriteLine(string2a);
            string string2b = @"The path is C:\PublicDocuments\Report1.doc";
            Console.WriteLine(string2b);

            char[] chars = { 'w', 'o', 'r', 'd' };
            

            // Create a string from a character array.
            string string11 = new string(chars);
            Console.WriteLine(string11);

            // Create a string that consists of a character repeated 20 times.
            string string2 = new string('c', 20);
            Console.WriteLine(string2);


            string string12 = "Today is " + DateTime.Now.ToString("D") + ".";
            Console.WriteLine(string12);

            string string22 = "This is one sentence. " + "This is a second. ";
            string12 += "This is a third sentence.";
            Console.WriteLine(string22);

            string sentence = "This sentence has five words.";
            // Extract the second word.
            int startPosition = sentence.IndexOf(" ") + 1;
            string word2 = sentence.Substring(startPosition,
                                              sentence.IndexOf(" ", startPosition) - startPosition);
            Console.WriteLine("Second word: " + word2);

            DateTime dateAndTime = new DateTime(2011, 7, 6, 7, 32, 0);
            double temperature = 68.3;
            string result = String.Format("At {0:t} on {0:D}, the temperature was {1:F1} degrees Fahrenheit.",
                                          dateAndTime, temperature);
            Console.WriteLine(result);
        }
    }
}
