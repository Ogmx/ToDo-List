﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            //延迟加载
            List<string> list = new List<string>() { "John", "Mike", "kake", "Juan" };
            var result = list.Where(s => s.StartsWith("J"));
            //var result = list.OrderBy(s => s);
            
            //var result = from s in list where s.StartsWith("J") select s;
            //var result = from s in list orderby s select s;

            foreach (var element in result)
            {
                Console.WriteLine(element);
            }

            list.Add("JO");
            list.Add("Ben");

            Console.WriteLine("____________________________");



            foreach (var element in result)
            {
                Console.WriteLine(element);
            }

            Console.ReadLine();
        }
    }
}
