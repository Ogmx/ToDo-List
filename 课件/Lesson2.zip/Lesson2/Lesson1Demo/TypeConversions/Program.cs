﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeConversions
{
    //
    class Program
    {
        static void Main(string[] args)
        {
            //Implicit conversions
            int i1 = 10;
            int i2 = 20;
            long sum = i1 + i2;

            //Explicit conversions (casts)
            long value = 3000;
            int i3 = (int)value;

            long val = 30000000000;
            //int i = checked((int)val);

            //Conversions with helper classes

            string str = "123";
            int i4 = Int32.Parse(str);
            Console.WriteLine("i4 = {0}", i4);
            Console.ReadLine();

            //boxing unboxing
            int myIntNumber = 20;
            object myObject = myIntNumber; //box the int
            int mySecondNumber = (int)myObject; //unbox it back into a int

            EqualsDemo.EqualsDemo1.ReferenceEqualsTest();
            Console.ReadLine();
        }
    }
}

namespace EqualsDemo
{
    //Equals() * 2,ReferenceEquals() , ==
    class SomeClass
    { }

    class EqualsDemo1
    {
        public static void ReferenceEqualsTest()
        {
            SomeClass x = new SomeClass();
            SomeClass y = new SomeClass();
            SomeClass z = null;
            bool b1 = ReferenceEquals(null, null);
            bool b2 = ReferenceEquals(null, x);
            bool b3 = ReferenceEquals(x, y);
            bool b4 = ReferenceEquals(1, 1); //box false;
            bool b5 = ReferenceEquals("1", "1");


            bool b6 = x.Equals(y);
            bool b7 = x.Equals(null);

            // bool b8 = z.Equals(x);

            bool b9 = Equals(x, y);
            bool b10 = Equals(1, 1);

            bool b11 = x == y;
            bool b12 = null == x;
            bool b13 = 1 == 1;
            bool b14 = "a" == "a";
        }

    }
}
