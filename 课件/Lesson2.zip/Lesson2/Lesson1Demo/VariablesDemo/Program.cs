﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariablesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //int i;
            //Console.WriteLine("i = {0}", i);

            int i = 0;
            Console.WriteLine("i = {0}", i);

            //mutiple variables
            int x = 1, y = 2, c = 3;

            //byte b = 256;

            //float f1 = 33;
            //float f2 = 33.3;

            Console.ReadLine();
        }
    }
}
