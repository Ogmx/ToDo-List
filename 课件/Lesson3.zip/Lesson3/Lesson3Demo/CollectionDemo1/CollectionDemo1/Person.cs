using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionDemo1
{
   [Serializable]
   public class Person
   {
      public Person(string name)
      {
         this.name = name;
      }

      private string name;

      public override string ToString()
      {
         return name;
      }
	
   }
}
