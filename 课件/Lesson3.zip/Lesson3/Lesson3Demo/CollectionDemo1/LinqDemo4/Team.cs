﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryOperators
{
    public class Team
    {
        public string Name { get; set; }

        public int[] Years { get; set; }
    }
}
