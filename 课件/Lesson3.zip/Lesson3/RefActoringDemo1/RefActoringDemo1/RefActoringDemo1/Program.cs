﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefActoringDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    class CaclatePrice1
    {
        public double PriceOrder(ProductInfo product, int quantity, ShippingMehtodInfo shippingMethod)
        {
            double basePrice = product.BasePrice * quantity;
            double discount = Math.Max(quantity - product.DiscountThreshold, 0) * product.BasePrice * product.DiscountRate;
            double shippingPerCase = (basePrice > shippingMethod.DiscountThreshold) ? shippingMethod.DiscountedFee : shippingMethod.FeePerCase;
            double shippingCost = quantity * shippingPerCase;
            double price = basePrice - discount + shippingCost;
            return price;
        }
    }

    class ProductInfo
    {
        public double BasePrice { get; set; }

        public double DiscountThreshold { get; set; }

        public double DiscountRate { get; set; }
        
    }

    class ShippingMehtodInfo
    {
        public double DiscountThreshold { get; set; }

        public double DiscountedFee { get; set; }

        public double FeePerCase { get; set; }
    }


    class CaclatePrice2
    {
        public double PriceOrder2(ProductInfo product, int quantity, ShippingMehtodInfo shippingMethod)
        {
            double basePrice = product.BasePrice * quantity;
            double discount = Math.Max(quantity - product.DiscountThreshold, 0) * product.BasePrice * product.DiscountRate;
            double price = ApplyShipping(basePrice, shippingMethod, quantity, discount);
            return price;
        }

        public double ApplyShipping(double basePrice, ShippingMehtodInfo shippingMethod, int quantity, double discount)
        {
            double shippingPerCase = (basePrice > shippingMethod.DiscountThreshold) ? shippingMethod.DiscountedFee : shippingMethod.FeePerCase;
            double shippingCost = quantity * shippingPerCase;
            double price = basePrice - discount + shippingCost;
            return price;
        }
    }

    class CaclatePrice3
    {
        public double PriceOrder3(ProductInfo product, int quantity, ShippingMehtodInfo shippingMethod)
        {
            double basePrice = product.BasePrice * quantity;
            double discount = Math.Max(quantity - product.DiscountThreshold, 0) * product.BasePrice * product.DiscountRate;
            PriceData priceData = new PriceData() { BasePrice = basePrice, Discount = discount, Quantity = quantity };
            double price = ApplyShipping(priceData, shippingMethod);
            return price;
        }

        public double ApplyShipping(PriceData priceData ,ShippingMehtodInfo shippingMethod)
        {
            double shippingPerCase = (priceData.BasePrice > shippingMethod.DiscountThreshold) ? shippingMethod.DiscountedFee : shippingMethod.FeePerCase;
            double shippingCost = priceData.Quantity * shippingPerCase;
            double price = priceData.BasePrice - priceData.Discount + shippingCost;
            return price;
        }
    }

    class PriceData
    {
        public double BasePrice { get; set; }
        public int Quantity { get; set; }
        public double Discount { get; set; }
    }
}

