﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataGridDemo.Model;
using System.Collections.ObjectModel;

namespace DataGridDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            ObservableCollection<Students> memberData = new ObservableCollection<Students>();
            Students s1 = new Students() { Name = "xiao ming", Age = 7 , Email="xxx@sss.com" };
            Students s2 = new Students() { Name = "xiao qiang", Age = 8, Email = "111@sss.com" };
            Students s3 = new Students() { Name = "xiao hong", Age = 9, Email = "222@sss.com" };

            memberData.Add(s1);
            memberData.Add(s2);
            memberData.Add(s3);
            this.dataGrid.DataContext = memberData;

        }

        
    }
}
