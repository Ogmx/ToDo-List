﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataGridDemo2.Model;
using System.Collections.ObjectModel;

namespace DataGridDemo2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ObservableCollection<Student> memberData = new ObservableCollection<Student>();
            memberData.Add(new Student()
            {
                Name = "Joe",
                Age = "23",
                Sex = SexOpt.Male,
                Pass = true,
                Email = new Uri("mailto:Joe@school.com"),
                Birthday = new DateTime(1970, 1, 1)
            });
            memberData.Add(new Student()
            {
                Name = "Mike",
                Age = "20",
                Sex = SexOpt.Male,
                Pass = false,
                Email = new Uri("mailto:Mike@school.com"),
                Birthday = new DateTime(1980, 1, 1)
            });
            memberData.Add(new Student()
            {
                Name = "Lucy",
                Age = "25",
                Sex = SexOpt.Female,
                Pass = true,
                Email = new Uri("mailto:Lucy@school.com"),
                Birthday = new DateTime(1990, 1, 1)
            });
            this.dataGrid.DataContext = memberData;
        }
    }
}
