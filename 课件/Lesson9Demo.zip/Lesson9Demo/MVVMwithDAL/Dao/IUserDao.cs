﻿using MVVMwithDAL.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMwithDAL.Dao
{
    public interface IUserDao
    {
        List<UserDto> GetAllUsers();
    } 
}
