﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MVVMwithDAL.Dto;
using System.Data.SqlClient;
using MVVMwithDAL.Util;

namespace MVVMwithDAL.Dao.impl
{
    public class UserDaoImpl : IUserDao
    {
        public List<UserDto> GetAllUsers()
        {
            List<UserDto> allUsers = new List<UserDto>();
            try
            {
                using (SqlConnection conn = DBConnectionUtil.GetConnection())
                {
                    string commandText = "select * from UserTable";
                    SqlCommand command = new SqlCommand(commandText, conn);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            UserDto user = new UserDto();
                            user.Id = reader.GetString(0);
                            user.Name = reader.GetString(1);
                            user.Age = reader.GetInt32(2);
                            allUsers.Add(user);
                        }
                    }
                }
            }
            catch (Exception)
            {
                //异常处理 这里是直接抛出了
                throw;
            }

            return allUsers;
        }
    }
}
