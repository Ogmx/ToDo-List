﻿using MVVMwithDAL.Dto;
using MVVMwithDAL.Service;
using MVVMwithDAL.Service.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMwithDAL.Model
{
    public class UserListModel
    {
        private List<UserDto> _allUsers = new List<UserDto>();
        private IUserService userService = new UserServiceImpl();
        public List<UserDto> AllUsers
        {
            get
            {
                
                    _allUsers = userService.GetAllUsers();
                    
               
                return _allUsers;
            }
        }
    }
}
