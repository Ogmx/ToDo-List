﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MVVMwithDAL.Dto;
using MVVMwithDAL.Dao;
using MVVMwithDAL.Dao.impl;

namespace MVVMwithDAL.Service.Impl
{
    public class UserServiceImpl : IUserService
    {
        private IUserDao userDao = new UserDaoImpl();
        public List<UserDto> GetAllUsers()
        {
            return userDao.GetAllUsers();
        }
    }
}
