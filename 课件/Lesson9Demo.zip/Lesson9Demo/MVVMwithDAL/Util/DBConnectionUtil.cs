﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMwithDAL.Util
{
    public static class DBConnectionUtil
    {

        public static SqlConnection GetConnection()
        {
            SqlConnection sqlConn = new SqlConnection();
            sqlConn.ConnectionString = GetConnectionString(ConnectionStringPattern.BySqlConnectionStringBuilder);
            sqlConn.Open();
            return sqlConn;
        }
        private static string GetConnectionString(ConnectionStringPattern pattern)
        {
            string connectionString = string.Empty;

            switch (pattern)
            {
                case ConnectionStringPattern.ByString:
                    connectionString = "Data Source=.;Initial Catalog=docave62;Integrated Security=True";
                    break;
                case ConnectionStringPattern.BySqlConnectionStringBuilder:
                    SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder();
                    sqlBuilder.DataSource = @"localhost\SQLEXPRESS";
                    sqlBuilder.InitialCatalog = "UserDB";
                    sqlBuilder.IntegratedSecurity = false;
                    sqlBuilder.UserID = "sa";
                    sqlBuilder.Password = "sa123456";
                    connectionString = sqlBuilder.ConnectionString;
                    break;
                case ConnectionStringPattern.ByConfiguration:
                    connectionString = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
                    break;

                default:
                    throw new Exception("Pattern Error");
            }

            return connectionString;
        }
    }

    public enum ConnectionStringPattern
    {
        ByString,
        BySqlConnectionStringBuilder,
        ByConfiguration
    }
}
