﻿using MVVMwithDAL.Dto;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMwithDAL.Util.ViewModel
{
    public static class UserConverUtil
    {
        public static ObservableCollection<UserDto> ConvertListToObservableCollection(List<UserDto> userList)
        {
            ObservableCollection<UserDto> observableUsers = new ObservableCollection<UserDto>();
            if (userList != null && userList.Count > 0)
            {
                userList.ForEach( user => observableUsers.Add(user));
            }
            return observableUsers;
        }
    }
}
