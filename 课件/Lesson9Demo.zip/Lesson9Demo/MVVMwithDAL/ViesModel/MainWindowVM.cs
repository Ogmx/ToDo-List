﻿using MVVMwithDAL.Dto;
using MVVMwithDAL.Model;
using MVVMwithDAL.Util.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMwithDAL.ViesModel
{
    public class MainWindowVM : INotifyPropertyChanged
    {
        #region properties
        private ObservableCollection<UserDto> _allUsers = new ObservableCollection<UserDto>();
        private readonly UserListModel _userListModel ;

        public ObservableCollection<UserDto> AllUsers
        {
            get { return _allUsers; }

            set
            {
                _allUsers = value;
                OnPropertyChanged("AllUsers");
            }
        }
        #endregion
        #region Command
        public DelegateCommands ShowAllUsers { get; set; }
        #endregion
        #region Constructor
        public MainWindowVM()
        {
            // AllUsers = UserConverUtil.ConvertListToObservableCollection( _userListModel.AllUsers); 
            //List<UserDto> temp = new List<UserDto>();
            //temp.Add(new UserDto() { Id = "1", Age = 1, Name = "1" });
            //temp.Add(new UserDto() { Id = "2", Age = 2, Name = "2" });
            //_allUsers = UserConverUtil.ConvertListToObservableCollection(temp);
        }

        public MainWindowVM(UserListModel userListModel)
        {
            _userListModel = userListModel;
            //_allUsers = UserConverUtil.ConvertListToObservableCollection(_userListModel.AllUsers);
            ShowAllUsers = new DelegateCommands(param => 
            {
                AllUsers = UserConverUtil.ConvertListToObservableCollection(_userListModel.AllUsers);
                //OnPropertyChanged("AllUsers");
            });

        }
        #endregion

        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyName)
        {
            if (propertyName != null)
            {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}
